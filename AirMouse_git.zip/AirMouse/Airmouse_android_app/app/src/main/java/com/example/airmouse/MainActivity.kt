package com.example.airmouse

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.FirebaseApp
import com.google.firebase.database.FirebaseDatabase
import kotlin.math.abs

class MainActivity : AppCompatActivity(), SensorEventListener {

    private lateinit var sensorManager: SensorManager
    private var gyroSensor: Sensor? = null
    private lateinit var database: FirebaseDatabase

    private var isStreaming = false
    private var sessionCode = "test123"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        FirebaseApp.initializeApp(this)

        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        gyroSensor = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)

        database = FirebaseDatabase.getInstance()

        val editSession = findViewById<EditText>(R.id.editSession)
        val btnConnect = findViewById<Button>(R.id.btnConnect)
        val btnClick = findViewById<Button>(R.id.btnClick)
        val btnCalibrate = findViewById<Button>(R.id.btnCalibrate)
        val txtStatus = findViewById<TextView>(R.id.txtStatus)

        btnConnect.setOnClickListener {
            sessionCode = editSession.text.toString().ifEmpty { "test123" }
            isStreaming = true
            txtStatus.text = "Connected ✔\nSession: $sessionCode"
            btnConnect.text = "Connected"
        }

        btnClick.setOnClickListener {
            if (isStreaming) {
                database.reference
                    .child("sessions")
                    .child(sessionCode)
                    .child("cursor")
                    .child("click")
                    .setValue(true)
            }
        }

        btnCalibrate.setOnClickListener {
            txtStatus.text = "Calibrated ✔"
        }
    }

    override fun onResume() {
        super.onResume()
        gyroSensor?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
    }

    override fun onPause() {
        super.onPause()
        sensorManager.unregisterListener(this)
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (!isStreaming || event?.sensor?.type != Sensor.TYPE_GYROSCOPE) return

        val gyroX = event.values[0]
        val gyroY = event.values[1]

        val threshold = 0.15f

        val x = if (abs(gyroY) > threshold) -gyroY * 8 else 0f
        val y = if (abs(gyroX) > threshold) gyroX * 8 else 0f

        val data = mapOf(
            "x" to x,
            "y" to y,
            "click" to false
        )

        database.reference
            .child("sessions")
            .child(sessionCode)
            .child("cursor")
            .setValue(data)
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}

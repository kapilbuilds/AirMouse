import firebase_admin
from firebase_admin import credentials, db
import pyautogui
import time

# ================== CONFIG ==================
DATABASE_URL = "https://mouse-644fc-default-rtdb.firebaseio.com/"
SESSION_CODE = "test123"

SENSITIVITY = 12        # cursor speed
DEADZONE = 0.12         # ignore tiny movements
MAX_MOVE = 30           # prevent jump to screen corners
# ============================================

# Disable PyAutoGUI fail-safe (safe here)
pyautogui.FAILSAFE = False

# Init Firebase
cred = credentials.Certificate("serviceAccountKey.json")
firebase_admin.initialize_app(cred, {
    "databaseURL": DATABASE_URL
})

ref = db.reference(f"/sessions/{SESSION_CODE}/cursor")

print("✅ Receiver started")
print(f"📡 Listening to /sessions/{SESSION_CODE}/cursor")

# ------------------------------------------------
def clamp(value, min_val, max_val):
    return max(min(value, max_val), min_val)

def listener(event):
    data = event.data
    if not isinstance(data, dict):
        return

    dx = data.get("x", 0)
    dy = data.get("y", 0)
    click = data.get("click", False)

    # Deadzone filter
    if abs(dx) < DEADZONE:
        dx = 0
    if abs(dy) < DEADZONE:
        dy = 0

    # Apply sensitivity
    move_x = clamp(dx * SENSITIVITY, -MAX_MOVE, MAX_MOVE)
    move_y = clamp(dy * SENSITIVITY, -MAX_MOVE, MAX_MOVE)

    # Move mouse
    if move_x != 0 or move_y != 0:
        pyautogui.moveRel(move_x, move_y, duration=0)

    # Click support
    if click:
        pyautogui.click()
        ref.child("click").set(False)

# Start listening
ref.listen(listener)

# Keep script alive
while True:
    time.sleep(1)
